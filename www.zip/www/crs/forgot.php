<?php

require_once("Style/header.php");
require_once("inc/forgot.php");

OpenWorkSpace();

form_lostPassword();


CloseWorkSpace();



require_once("Style/footer.php");



?>
