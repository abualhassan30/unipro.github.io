<?PHP

function OpenWorkSpace(){

echo "        <div class=\"OpenWorkSpace\">";
}







function CloseWorkSpace(){


echo "</div>";

}







?>