<?PHP

require("Class.php");
$x = new Booking();
$x->DrowTable(1,"2019-08-10","2020-12-01");















?>