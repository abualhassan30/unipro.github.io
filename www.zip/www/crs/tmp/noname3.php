<?php

//

require_once("sdfsdfsd");







      $x= $_GET["sdfsdf"];
      $x= $_POST["sdfsdf"];
      $user = $_REQUEST["text1"];

      $user = $_SESSION["user_id"];






echo

    if

 switch($user){


     case "admin";

     break;


     case "Manger";

     break;


     case "Doctor";

     break;



 }





?>
