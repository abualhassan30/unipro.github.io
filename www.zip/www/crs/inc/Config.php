<?PHP
  ini_set('display_errors', 1);
  ini_set('display_startup_errors', 1);

  define("_config_db_host","localhost");
  define("_config_db_user","project1_root");
  define("_config_db_pass","Project1123456");
  define("_config_db_name","project1_dbs");


//  define("_config_start_part","2019-08-01");
//  define("_config_end_part","2020-03-01");



?>