<?php

require_once("Style/header.php");



OpenWorkSpace();


?>

<div>
    <blockquote>
        <span style="font-weight: 700;">جامعة القصيم :&nbsp;</span></blockquote>
</div>
<ul>
    <li>المملكة العربية السعودية - القصيم - المليداء ، شمال مطار الأمير نايف (القصيم) 
    ، بجوار محطة توزيع المنتجات البترولية (أرامكو)</li>
    <li>سنترال الجامعة : 3800050 (16) (966) +</li>
    <li>بريد إلكتروني : info@qu.edu.sa<br>
&nbsp;</li>
</ul>
<p><strong><br>
&nbsp;</strong></p>
<blockquote>
    <strong>إدارة العلاقات العامة :</strong></blockquote>
<ul>
    <li>العنوان : (مبنى الإدارة العامة - الدور الخامس).</li>
    <li>هاتف : 3800545 (16) (966) +</li>
    <li>فاكس : 3803070 (16) (966) +</li>
</ul>
<p><br>
&nbsp;</p>
<blockquote>
    <span style="font-weight: 700; color: rgb(51, 51, 51); font-size: 12px;">
    للشكاوى والمقترحات يمكن التواصل مع خدمة المستفيدين&nbsp; :</span></blockquote>
<ul>
    <li>سنترال الجامعة : 3802772 (16) (966) +</li>
    <li>بريد إلكتروني : csc@qu.edu.sa</li>
</ul>

<?


CloseWorkSpace();



require_once("Style/footer.php");



?>